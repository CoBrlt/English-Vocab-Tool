class Word{

    constructor(french="", english=""){
        this.french = french;
        this.english = english;
    }

}