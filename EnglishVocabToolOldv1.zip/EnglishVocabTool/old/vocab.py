import tools as Tools

def display(root, all_words_tab):
    Tools.remove_all_widgets(root)

    Tools.create_frame()

    Tools.input_select_input()
    
    Tools.text_field()
    Tools.input_add_text()
    
    return