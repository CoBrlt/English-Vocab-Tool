import tools as Tools

def main():
    Tools.init()
    return


main()


#C:\Users\coren\AppData\Local\Programs\Python\Python310\python.exe app.py
